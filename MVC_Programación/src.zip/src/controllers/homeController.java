package controllers;

import views.homeView;

public class homeController {

	private homeView homeV;
	public void home() {
		homeV.homeViewP();
		homeV.setVisible(true);
	}
}
