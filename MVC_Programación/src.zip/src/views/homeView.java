package views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controllers.AuthController;
import controllers.homeController;
import models.AuthModel;
import models.homeModel;
import java.awt.GridLayout;

public class homeView extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	
	public homeView() {
		setTitle("Home");
		setBounds(100, 100, 750, 700);
	    setResizable(true);
	    getContentPane().setLayout(new BorderLayout());
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setResizable(false);
	    setLocationRelativeTo(null);
		
	    contentPane = new JPanel();
	    contentPane.setLayout(null);
	    setContentPane(contentPane);
	    
	    homeViewP();
	}

	public void homeViewP() {
		
	    Font titulos = new Font("Inika", Font.BOLD, 32);
	    Font subtitulos = new Font("Inika", Font.ROMAN_BASELINE, 22);
	    Font texto = new Font("Inika", Font.ROMAN_BASELINE, 16);

	    
	    JPanel homeFondo = new JPanel();
	    homeFondo.setBounds(0, 0, 750, 700);
	    homeFondo.setBackground(new Color(0, 128, 128));
	    getContentPane().add(homeFondo);
	    homeFondo.setLayout(new BorderLayout(0, 0));
	    contentPane.add(homeFondo);
	    
	    JPanel panel = new JPanel();
	    homeFondo.add(panel, BorderLayout.NORTH);
	    
	    JLabel lblNewLabel = new JLabel("New label");
	    panel.add(lblNewLabel);
	    
	    JLabel lblNewLabel_1 = new JLabel("New label");
	    panel.add(lblNewLabel_1);
	    
	    JLabel lblNewLabel_2 = new JLabel("New label");
	    panel.add(lblNewLabel_2);
	    
	    JLabel lblNewLabel_3 = new JLabel("New label");
	    panel.add(lblNewLabel_3);
	    
	    JPanel panel_1 = new JPanel();
	    homeFondo.add(panel_1, BorderLayout.CENTER);
	    panel_1.setLayout(new GridLayout(1, 0, 0, 0));
	    
	    JLabel lblNewLabel_4 = new JLabel("New label");
	    panel_1.add(lblNewLabel_4);
	    
	    JLabel lblNewLabel_5 = new JLabel("New label");
	    panel_1.add(lblNewLabel_5);
	    
	    JLabel lblNewLabel_6 = new JLabel("New label");
	    panel_1.add(lblNewLabel_6);
	    
	    JLabel lblNewLabel_7 = new JLabel("New label");
	    panel_1.add(lblNewLabel_7);
	    
	    
	}

}
