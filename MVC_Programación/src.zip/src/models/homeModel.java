package models;

public class homeModel {
	
	public homeModel() {
		
	}

}
